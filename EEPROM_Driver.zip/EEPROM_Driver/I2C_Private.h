/*
 * I2C_Private.h
 *
 *  Created on: Sep 6, 2024
 *      Author: asus
 */

#ifndef I2C_PRIVATE_H_
#define I2C_PRIVATE_H_
#define I2C_TWBR_Reg  *((volatile u8*)0x20)
#define I2C_TWSR_Reg  *((volatile u8*)0x21)
#define I2C_TWDR_Reg  *((volatile u8*)0x23)
#define I2C_TWAR_Reg  *((volatile u8*)0x22)
#define I2C_TWCR_Reg  *((volatile u8*)0x56)
#define I2C_Start_ACK   0x08
#define I2C_RepeatedStart_ACK   0x10
#define I2C_SLA_W_ACK   0x18
#define I2C_SLA_R_ACK   0x40
#define I2C_WRITEDATA_ACK   0x28
#define I2C_READDATA_ACK   0x50



#endif /* I2C_PRIVATE_H_ */
