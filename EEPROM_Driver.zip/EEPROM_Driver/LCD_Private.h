/*

 * LCD_Private.h
 *
 *  Created on: Aug 22, 2024
 *      Author: asus
 */

#ifndef LCD_PRIVATE_H_
#define LCD_PRIVATE_H_

#define LCD_u8_MODE_8_BIT  0
#define LCD_u8_MODE_4_BIT  1


#endif /* LCD_PRIVATE_H_ */
