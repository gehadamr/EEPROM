/*
 * EEPROM_Program.c
 *
 *  Created on: Sep 7, 2024
 *      Author: asus
 */
#include "STD_TYPES.h"
#include "BIT_MATH.h"
#define F_CPU 8000000UL
#include <util/delay.h>
#include "I2C_Interface.h"
#include "EEPROM_Interface.h"
#include "EEPROM_Config.h"
#include "EEPROM_Private.h"

static u8 check_errorState(I2C_ERROR_STATE  Copy_ENUM_ERROR){
	u8 localStateError=STD_TYPES_OK;
	if(Copy_ENUM_ERROR!=I2C_OK){
			localStateError=STD_TYPES_NOK;
		}
	return localStateError;
}


u8 EEPROM_Write_DATAByte(u16 copy_u16_Address_Byte ,u8 copy_u8_Data){
	u8 localStateError=STD_TYPES_OK;
	//start condition this function return errorstate from the data type of enum
	I2C_ERROR_STATE  LOCAL_ERROR=I2C_OK;
	LOCAL_ERROR =I2C_u8SendStartCondition();
	//check LOCAL_ERROR sc is ok or not
	localStateError=check_errorState(LOCAL_ERROR );
	if (localStateError != STD_TYPES_OK) return localStateError;
	//send slave  adddress with write operation
	LOCAL_ERROR=I2C_u8SendSlaveAddressWithWrite((EEPROM_FIXEDADDRESS)|(EEPROM_u8_A2<<2)|(copy_u16_Address_Byte>>8));// the slave address is   7 MSB
	//check LOCAL_ERROR slave address is ok or not
	localStateError=check_errorState(LOCAL_ERROR );
	if (localStateError != STD_TYPES_OK) return localStateError;
	//send rest of slave address
	LOCAL_ERROR= I2C_u8SendDataByte((u8)copy_u16_Address_Byte);
	//check LOCAL_ERROR slave address is ok or not
	localStateError=check_errorState(LOCAL_ERROR );
	if (localStateError != STD_TYPES_OK) return localStateError;
	//send DATA
	LOCAL_ERROR=I2C_u8SendDataByte(copy_u8_Data);
	//check LOCAL_ERROR slave address is ok or not
	localStateError=check_errorState(LOCAL_ERROR );
	if (localStateError != STD_TYPES_OK) return localStateError;
    //stop condition
	I2C_u8SendStopCondition();
    //delay for the next start  TWR=5msec
	_delay_ms(5);
	return localStateError;
}
u8 EEPROM_Read_DATAByte(u16 copy_u16_Address_Byte ,u8 *copy_u8_ReturnedData){
	u8 localStateError=STD_TYPES_OK;
		//start condition this function return errorstate from the data type of enum
		I2C_ERROR_STATE  LOCAL_ERROR=I2C_OK;
		//check pointer
		if(copy_u8_ReturnedData!=NULL&& copy_u16_Address_Byte <= 1023){
			    LOCAL_ERROR =I2C_u8SendStartCondition();
				//check LOCAL_ERROR sc is ok or not
				localStateError=check_errorState(LOCAL_ERROR );
		        if (localStateError != STD_TYPES_OK) return localStateError;
				//send slave  adddress with write operation
				LOCAL_ERROR=I2C_u8SendSlaveAddressWithWrite((EEPROM_FIXEDADDRESS)|(EEPROM_u8_A2<<2)|(copy_u16_Address_Byte>>8));// the slave address is   7 MSB
				//check LOCAL_ERROR slave address is ok or not
				localStateError=check_errorState(LOCAL_ERROR );
		        if (localStateError != STD_TYPES_OK) return localStateError;

				//send rest of slave address
				LOCAL_ERROR=I2C_u8SendDataByte((u8)copy_u16_Address_Byte);
			    //check LOCAL_ERROR slave address is ok or not
			    localStateError=check_errorState(LOCAL_ERROR );
		        if (localStateError != STD_TYPES_OK) return localStateError;

			    //resend sc to change write to read operation
			    LOCAL_ERROR= I2C_u8SendRestartCondition();
			    //check LOCAL_ERROR repeated start condition is ok or not
			     localStateError=check_errorState(LOCAL_ERROR );
			        if (localStateError != STD_TYPES_OK) return localStateError;

					//read slave  adddress with read operation
			     LOCAL_ERROR= I2C_u8SendSlaveAddressWithRead((EEPROM_FIXEDADDRESS)|(EEPROM_u8_A2<<2)|(copy_u16_Address_Byte>>8));
			     //check LOCAL_ERROR slave address is ok or not
			     localStateError=check_errorState(LOCAL_ERROR );
			        if (localStateError != STD_TYPES_OK) return localStateError;

 			     //read data from EEPROM
			     LOCAL_ERROR= I2C_u8ReadDataByte(copy_u8_ReturnedData);
                  //check LOCAL_ERROR slave address is ok or not
                  localStateError=check_errorState(LOCAL_ERROR );
                  if (localStateError != STD_TYPES_OK) return localStateError;

                  //stop condition
                 	I2C_u8SendStopCondition();
                     //delay for the next start  TWR=5msec
                 	_delay_ms(5);
		}else   {
		localStateError=STD_TYPES_NOK;

		}
		return localStateError;
}

