/*
 * I2C_Config.h
 *
 *  Created on: Sep 6, 2024
 *      Author: asus
 */

#ifndef I2C_CONFIG_H_
#define I2C_CONFIG_H_



#endif /* I2C_CONFIG_H_ */
