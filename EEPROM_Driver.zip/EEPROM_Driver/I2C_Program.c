/*
 * I2C_Program.c
 *
 *  Created on: Sep 6, 2024
 *      Author: asus
 */
#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "I2C_Interface.h"
#include "I2C_Private.h"


void I2C_void_Master_inti(void)
{
	//set prescaler value =0
	CLR_BIT(I2C_TWSR_Reg,I2C_TWPS0_PIN);
	CLR_BIT(I2C_TWSR_Reg,I2C_TWPS1_PIN);
	//SET TWBR  with the value from freq equation & set clk =200KHZ
     I2C_TWBR_Reg=12;
     //Enable ACK
     SET_BIT(I2C_TWCR_Reg,I2C_TWEA_PIN);
     //Enable I2C
     SET_BIT(I2C_TWCR_Reg,I2C_TWEN_PIN);
}
I2C_ERROR_STATE I2C_void_Slave_inti(u8 Copy_u8Slave_address){
	I2C_ERROR_STATE   LOCAL_ERRORSTATE=I2C_OK;
	//set slave address in  TWAR
	if(Copy_u8Slave_address>=0&&Copy_u8Slave_address<=127){
		I2C_TWAR_Reg=(Copy_u8Slave_address<<1);
	      //Enable ACK
	     SET_BIT(I2C_TWCR_Reg,I2C_TWEA_PIN);
	     //Enable I2C
	     SET_BIT(I2C_TWCR_Reg,I2C_TWEN_PIN);
	}else{

		LOCAL_ERRORSTATE=I2C_outofSlave_addresses;
	}
	return LOCAL_ERRORSTATE;
}
I2C_ERROR_STATE I2C_u8SendStartCondition(void){
	I2C_ERROR_STATE   LOCAL_ERRORSTATE=I2C_OK;

	//set TWESTA pin
    SET_BIT(I2C_TWCR_Reg,I2C_TWSTA_PIN);
	//clear TWINT FLAG
    SET_BIT(I2C_TWCR_Reg,I2C_TWINT_PIN);
    //Enable I2C
   	SET_BIT(I2C_TWCR_Reg,I2C_TWEN_PIN);
 	     //i can make three steps in one step I2C_TWCR_Reg = (1 << I2C_TWSTA_PIN) | (1 << I2C_TWEN_PIN) | (1 << I2C_TWINT_PIN);
	//wait flag for to bre uploaded
    while((GET_BIT(I2C_TWCR_Reg,I2C_TWINT_PIN))==0);
	//check ack for start
    if ((I2C_TWSR_Reg & 0xF8) !=I2C_Start_ACK){
            LOCAL_ERRORSTATE = I2C_SC_ERROR;  // Failed to send start condition
        }
    //clear start condition bit
    CLR_BIT(I2C_TWCR_Reg,I2C_TWSTA_PIN);

    return  LOCAL_ERRORSTATE;

}

//for repeated start condition
I2C_ERROR_STATE I2C_u8SendRestartCondition(void){
	I2C_ERROR_STATE   LOCAL_ERRORSTATE=I2C_OK;
		//set TWESTA pin
	    SET_BIT(I2C_TWCR_Reg,I2C_TWSTA_PIN);
		//clear TWINT FLAG
	    SET_BIT(I2C_TWCR_Reg,I2C_TWINT_PIN);
	    //Enable I2C
	 	   SET_BIT(I2C_TWCR_Reg,I2C_TWEN_PIN);
	 	 //i can make three steps in one step I2C_TWCR_Reg = (1 << I2C_TWSTA_PIN) | (1 << I2C_TWEN_PIN) | (1 << I2C_TWINT_PIN);
		//wait flag for to bre uploaded
	    while((GET_BIT(I2C_TWCR_Reg,I2C_TWINT_PIN))==0);
		//check ack for repeated start
	    if ((I2C_TWSR_Reg & 0xF8) !=I2C_RepeatedStart_ACK){
            LOCAL_ERRORSTATE = I2C_REPEATED_SC_ERROR;  // Failed to send start condition
	        }
	    else{
	    //clear start condition bit
	       CLR_BIT(I2C_TWCR_Reg,I2C_TWSTA_PIN);
	    }
	    return  LOCAL_ERRORSTATE;

	}
void I2C_u8SendStopCondition(void){
	//clear TWINT FLAG
	 SET_BIT(I2C_TWCR_Reg,I2C_TWINT_PIN);
	//stop condition
	 SET_BIT(I2C_TWCR_Reg,I2C_TWSTO_PIN);
}
I2C_ERROR_STATE I2C_u8SendSlaveAddressWithWrite(u8 Copy_u8Slave_address){
	I2C_ERROR_STATE   LOCAL_ERRORSTATE=I2C_OK;
	//write slave address  +0 in TWDR
	I2C_TWDR_Reg=(Copy_u8Slave_address<<1);
	CLR_BIT(I2C_TWDR_Reg,I2C_TWD0_PIN);
	/*Clear The Start Condition Bit*/
    CLR_BIT(I2C_TWCR_Reg, I2C_TWSTA_PIN);
	//clear TWINT FLAG
   SET_BIT(I2C_TWCR_Reg,I2C_TWINT_PIN);
   //wait flag for to bre uploaded
   while((GET_BIT(I2C_TWCR_Reg,I2C_TWINT_PIN))==0);
	//check ack for address slave and write pin
   if ((I2C_TWSR_Reg & 0xF8) !=I2C_SLA_W_ACK){
   	            LOCAL_ERRORSTATE = 	I2C_SLA_W_ERROR;
   	        }
   return LOCAL_ERRORSTATE;
}
I2C_ERROR_STATE I2C_u8SendSlaveAddressWithRead(u8 Copy_u8Slave_address){
	I2C_ERROR_STATE   LOCAL_ERRORSTATE=I2C_OK;
	//write slave address  +1 in WADR
	I2C_TWDR_Reg=(Copy_u8Slave_address<<1);
	SET_BIT(I2C_TWDR_Reg,I2C_TWD0_PIN);

	//clear TWINT FLAG
   SET_BIT(I2C_TWCR_Reg,I2C_TWINT_PIN);
   //wait flag for to bre uploaded
   while((GET_BIT(I2C_TWCR_Reg,I2C_TWINT_PIN))==0);
	//check ack for address slave and read pin
   if ((I2C_TWSR_Reg & 0xF8) !=I2C_SLA_R_ACK){
   	            LOCAL_ERRORSTATE = I2C_SLA_R_ERROR;
   	        }
   return LOCAL_ERRORSTATE;
}
I2C_ERROR_STATE I2C_u8SendDataByte(u8 Copy_u8Data){
	I2C_ERROR_STATE   LOCAL_ERRORSTATE=I2C_OK;
	//write data on TWDR
	I2C_TWDR_Reg=Copy_u8Data;
	//clear TWINT FLAG
	   SET_BIT(I2C_TWCR_Reg,I2C_TWINT_PIN);
	   //wait flag for to bre uploaded
	   while((GET_BIT(I2C_TWCR_Reg,I2C_TWINT_PIN))==0);
		//check ack for address slave and read pin
	   if ((I2C_TWSR_Reg & 0xF8) !=I2C_WRITEDATA_ACK){
	   	     LOCAL_ERRORSTATE = I2C_WRITEDATA_EEROR;
	   	        }
	   return LOCAL_ERRORSTATE;
	}
I2C_ERROR_STATE I2C_u8ReadDataByte(u8 *Copy_u8Data){
	I2C_ERROR_STATE   LOCAL_ERRORSTATE=I2C_OK;
//check on pointer
if(Copy_u8Data!=NULL){
	//clear TWINT FLAG
	SET_BIT(I2C_TWCR_Reg,I2C_TWINT_PIN);
	 //wait flag for to bre uploaded
     while((GET_BIT(I2C_TWCR_Reg,I2C_TWINT_PIN))==0);
	//check ack for address slave and read pin
   if ((I2C_TWSR_Reg & 0xF8) !=I2C_READDATA_ACK){
	   LOCAL_ERRORSTATE = I2C_READDATA_ERROR; }
   else{
	   *Copy_u8Data=I2C_TWDR_Reg;
	}

		}else{
			LOCAL_ERRORSTATE = I2C_NULL_POINTER_ERROR;
		}
return LOCAL_ERRORSTATE;
}

