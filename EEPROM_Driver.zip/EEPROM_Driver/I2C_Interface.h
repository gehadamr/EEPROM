/*
 * I2C_Interface.h
 *
 *  Created on: Sep 6, 2024
 *      Author: asus
 */

#ifndef I2C_INTERFACE_H_
#define I2C_INTERFACE_H_
// to return different type of errors
typedef enum{
	I2C_OK=1,//  order 1
	I2C_NOK,//  order 2
	I2C_outofSlave_addresses,// order 3
	I2C_SC_ERROR,// order 4
	I2C_REPEATED_SC_ERROR,// order 5
	I2C_SLA_W_ERROR,
	I2C_SLA_R_ERROR,
	I2C_WRITEDATA_EEROR,
	I2C_READDATA_ERROR,
	I2C_NULL_POINTER_ERROR


}I2C_ERROR_STATE;
#define I2C_TWPS1_PIN  1
#define I2C_TWPS0_PIN  0
#define I2C_TWEA_PIN   6
#define I2C_TWEN_PIN   2
#define I2C_TWSTA_PIN  5
#define I2C_TWINT_PIN  7
#define I2C_TWSTO_PIN  4
#define I2C_TWD0_PIN   0




void I2C_void_Master_inti(void);
I2C_ERROR_STATE I2C_void_Slave_inti(u8 Copy_u8Slave_address);
I2C_ERROR_STATE I2C_u8SendStartCondition(void);
I2C_ERROR_STATE I2C_u8SendRestartCondition(void); //for repeated start condition
void I2C_u8SendStopCondition(void);
I2C_ERROR_STATE I2C_u8SendSlaveAddressWithWrite(u8 Copy_u8Slave_address);
I2C_ERROR_STATE I2C_u8SendSlaveAddressWithRead(u8 Copy_u8Slave_address);
I2C_ERROR_STATE I2C_u8SendDataByte(u8 Copy_u8Data);
I2C_ERROR_STATE I2C_u8ReadDataByte(u8 *Copy_u8Data);



#endif /* I2C_INTERFACE_H_ */
