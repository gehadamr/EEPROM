/*
 * EEPROM_Config.h
 *
 *  Created on: Sep 7, 2024
 *      Author: asus
 */

#ifndef EEPROM_CONFIG_H_
#define EEPROM_CONFIG_H_

/*options
 * 0
 * 1
 */
#define EEPROM_u8_A2   0


#endif /* EEPROM_CONFIG_H_ */
