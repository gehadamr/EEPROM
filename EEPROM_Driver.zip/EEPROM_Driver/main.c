

#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "I2C_Interface.h"
#include "EEPROM_Interface.h"
#include "DIO_Interface.h"
#include "LCD_Interface.h"

int main() {
    static u8 RECIEVEDDATA;
    u8 writeStatus;
    u8 readStatus;
    DIO_voidInit();
    I2C_void_Master_inti();
    LCD_voidIntit();

    writeStatus = EEPROM_Write_DATAByte(5, 10); // address=5, data=10
    if (writeStatus == STD_TYPES_OK) {
        LCD_SendString("Transmitted: 10");
    } else {
        LCD_SendString("Write Error");
    }

    // Move to the next line
    LCD_u8GOTOXY(LCD_u8_LINE2, 0);

    // Read data from EEPROM
    readStatus = EEPROM_Read_DATAByte(5, &RECIEVEDDATA);
    if (readStatus == STD_TYPES_OK) {
        LCD_SendString("Received: ");
        LCD_SendNumber(RECIEVEDDATA);
    } else {
    	LCD_SendString("Read Error");
    }

    while (1) {

    }
}
