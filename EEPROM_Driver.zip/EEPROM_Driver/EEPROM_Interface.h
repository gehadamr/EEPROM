/*
 * EEPROM_Interface.h
 *
 *  Created on: Sep 7, 2024
 *      Author: asus
 */

#ifndef EEPROM_INTERFACE_H_
#define EEPROM_INTERFACE_H_
//data 0--->1023  needs 16 bit
u8 EEPROM_Write_DATAByte(u16 copy_u16_Address_Byte ,u8 copy_u8_Data);
u8 EEPROM_Read_DATAByte(u16 copy_u16_Address_Byte ,u8 *copy_u8_ReturnedData);


#endif /* EEPROM_INTERFACE_H_ */
