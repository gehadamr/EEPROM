/*
 * EEPROM_Private.h
 *
 *  Created on: Sep 7, 2024
 *      Author: asus
 */

#ifndef EEPROM_PRIVATE_H_
#define EEPROM_PRIVATE_H_
#define EEPROM_FIXEDADDRESS  0x50
static u8 check_errorState(I2C_ERROR_STATE  Copy_ENUM_ERROR);










#endif /* EEPROM_PRIVATE_H_ */
